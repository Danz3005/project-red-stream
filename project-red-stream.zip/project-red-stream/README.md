     Discontinued ⚒️
# Project Red Stream
[![Typing SVG](https://readme-typing-svg.demolab.com?font=Fira+Code&pause=1000&width=435&lines=RESPONSIVE+WEBSITE+TEMPLATE;)](https://git.io/typing-svg)

[<img src="https://img.shields.io/badge/Instagram-E4405F?style=for-the-badge&logo=instagram&logoColor=white" />](https://www.instagram.com/whxitte)

Red Stream is a full stack website project based on online blood donation. This  is a responsive and userfriendly website for making the process of blood donation easy.

# Discontinued: 
<b><i>Sorry to say, My working on this project is discontinued/dropped and will not do any further updates. This project is discontinued due to personal work loads, Anyway you can download this project in this condition and improve yourself.</b></i>

<b><i>Read how you can run this project on your system with all functions at the bottom of this page.</i></b>

There is an old basic version of this project, you can find the project at https://github.com/WH1T3-E4GL3/old-red-stream

# Screenshot
![252156140-465974c2-8b22-441d-8406-59be5657b8ef](https://github.com/WH1T3-E4GL3/project-red-stream/assets/118425907/58b9be48-7769-4a20-a920-f331b296aab9)



<b><strong><i>You can visit the website live at </i></strong></b>https://wh1t3-e4gl3.github.io/project-red-stream/


This is a web template that I have created and made available for private use. Please note the licensing terms before using this template.

## License

This work is licensed under the [Creative Commons Attribution-NonCommercial 4.0 International License](http://creativecommons.org/licenses/by-nc/4.0/).

![Creative Commons License](https://i.creativecommons.org/l/by-nc/4.0/88x31.png)

### Usage

You are free to download and use this template for personal projects, educational purposes, or for non-commercial use. However, any public or commercial use, including publishing, marketing, or using it in a commercial project, is not permitted without explicit permission.

### Adaptations

If you choose to adapt this template for your own needs, you must share your adaptations under the same Creative Commons Attribution-NonCommercial 4.0 International License. This ensures that others can benefit from your modifications while respecting the original creator's intentions.

Please read the full license text at [http://creativecommons.org/licenses/by-nc/4.0/](http://creativecommons.org/licenses/by-nc/4.0/) for more details.


# How you run this full website on your local computer ?

You can download and use xampp or WampServer to run a web server on your PC. After that start Apache and Mysql services and now you successfully made your PC into a server.<br>
You need to download and extract this project into xampp>htdocs folder.<br>
Now type localhost in your browser and enter and go to phpMyAdmin section. There you need to add a new database named 'redstream_db'. Inside that create 2 tables named 'registered_users' and 'response_back'.<br>
Inside registered_users table create the following columns:-  name, email, phone, password, bloodgroup, gender, birthdate, weight(kg), state, zipcode, district, area, landmark, donations, and received. All of them needs to be VARCHAR datatype except weight(kg) and zipcode is int datatype and birthdate is date datatype.<br>
In response_back table create only one column named email.<br>
And now  you are good to go. If you sucsessfully extracted the project file into htdocs folder of xampp, you can just run localhost/YourFolderName in your browser and you can see the and experience the  project live.<br>
I created the php scripts according to the database, tables and column names i mentioned. If you dont want to use that you can create your own database and columns and you need to change that in the php scripts also.



# Don't just copy, hit the star also😊




# Red Stream Blood Donation Web template
This include front end design and backend code for a blood donation based website

This pack comes under Creative Commons Attribution-NonCommercial license (CC BY-NC). 

~Work by Sethu Satheesh
  
  ©Sethu

